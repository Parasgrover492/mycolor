# Mycolor
Print colors from a predefined array randomly and stop before a color chosen by the user is printed. 
